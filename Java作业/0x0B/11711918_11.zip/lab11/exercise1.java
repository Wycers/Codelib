package lab11;

public class exercise1 {

    public static void main(String args[]) {
        Saler saler = new Saler();
        Teacher teacher = new Teacher();
        System.out.println(saler.toString());
        System.out.println(teacher.toString());
    }
}