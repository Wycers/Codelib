package lab12;

public class exercise1 {

	public static void main(String[] args) {
		Manager manager = new Manager();
		System.out.println(manager.toString());
	}

}
