package lab12;

public interface IEmployee {
	double calculatePay();

	boolean checkPromotionEligibility();
}
