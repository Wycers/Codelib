public class testGuessing {
	public static void main(String[] args) {
		GuessingGame game = new GuessingGame();
		game.timeControl();
		game.guess();
	}
}
